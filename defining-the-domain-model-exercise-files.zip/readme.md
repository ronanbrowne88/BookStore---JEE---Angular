# Module 04: Defining the Domain Model

The BookStore web application deals with books. Books are the basic domain model of the application and need to be mapped and then store into a relational database.


## Structure 

The BookStore application is divided into a Java EE REST back-end (`bookstore-back`) and an Angular front-end (`bookstore-front`).


### Bookstore Back 

The code of this module follows the [Maven](http://maven.apache.org/) directory structure. The `src/main/` directory contains the main source code while you will find the test class under `src/test/`. The `pom.xml` file is Maven specific and it describes the project and its dependencies.

Once [Maven](http://maven.apache.org/) and a [JDK 8](http://www.oracle.com/technetwork/java/javase/downloads/index.html) are installed, enter the following Maven commands:

* `mvn help:help`       : shows Maven help
* `mvn clean`           : cleans the `target` directory
* `mvn compile`         : compiles the code
* `mvn test`            : runs the test case (you need WildFly to be up and running)
* `mvn package`         : packages the code into a war file
* `mvn clean package`   : executes a clean and then a package

Once [Wildfly](http://wildfly.org/) is installed, deploy the war file and go to [http://localhost:8080/bookstore-back/]()



## Demo 

* In the `com.pluralsight.bookstore.model` package create a `Book` entity with an id (the primary key), a title, a description, a unitCost, an isbn, a publicationDate, nbOfPages, imagURL and a language.
* In the `com.pluralsight.bookstore.model` package create a `Language` enumeration.
* In the `src/main/resources/META-INF` directory create a `persistence.xml` file for the `bookStorePU` persistence unit.

*To execute the application you have to build it (`mvn clean package`) and then deploy the `bookstore-back.war` into [WildFly](https://wildfly.org).*
